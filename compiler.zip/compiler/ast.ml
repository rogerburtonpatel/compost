
type sym = SYM of sym 